#include "options.h"

Variables options;